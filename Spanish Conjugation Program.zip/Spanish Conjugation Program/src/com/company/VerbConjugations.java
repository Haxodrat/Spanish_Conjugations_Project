package com.company;

public class VerbConjugations
{
    public static void NewMethod()
    {





    }
}
